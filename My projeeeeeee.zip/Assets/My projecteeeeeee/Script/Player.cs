using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
   enum Direction
    {
        center,
        Left,
        Right
    }
    
    [SerializeField] private List<Sprite> center;
    [SerializeField] private List<Sprite> left;
    [SerializeField] private List<Sprite> right;
    
    [SerializeField] private PlayerBullet bullet;
    [SerializeField] private Transform parent;
    [SerializeField] private Transform bulletParent;




    public float speed;
    public float fireDelayTime;
    public float bulletspeed;

    public float fireTimer;
    private Direction dir = Direction.center;

    

    // Start is called before the first frame update
    void Start()
    {
        GetComponent<SpriteAnimation>().SetSprite(center, 0.2f);
    }

    // Update is called once per frame
    void Update()
    {
        //Ű���� �¿� ȭ��ǥ ���ʰ� �������� ���� ������ �ɴϴ� (-1 ~1)
        float x =Input.GetAxisRaw("Horizontal") * Time.deltaTime * speed;
        //Ű���� ���� ȭ��ǥ ���ʰ� �Ʒ����� ���� ������ �ɴϴ� (-1 ~1)
        float y =Input.GetAxisRaw("Vertical") * Time.deltaTime * speed;

        float clampX = Mathf.Clamp(transform.position.x + x, -2.5f, 2.5f);
        float clampY = Mathf.Clamp(transform.position.y + y, -4.5f, 4.5f);

        transform.position = new Vector3(clampX, clampY, 0f);

        if(x == 0 && dir != Direction.center)
        {
            dir = Direction.center;
            GetComponent<SpriteAnimation>().SetSprite(center, 0.2f);
        }
        else if(x > 0 && dir != Direction.Right)
        {
            dir = Direction.Right;
            GetComponent<SpriteAnimation>().SetSprite(right, 0.2f);
        }
        else if(x < 0 && dir != Direction.Left)
        {
            dir = Direction.Left;
            GetComponent<SpriteAnimation>().SetSprite(left, 0.2f);
        }

        fireTimer += Time.deltaTime;
        if (fireTimer >= fireDelayTime)
        {
            if(Input.GetKey(KeyCode.Space))
            {
                PlayerBullet b = Instantiate(bullet, parent);
                b.speed = bulletspeed;
                b.transform.SetParent(bulletParent);
                fireTimer = 0;

            }
        }

    }
}
