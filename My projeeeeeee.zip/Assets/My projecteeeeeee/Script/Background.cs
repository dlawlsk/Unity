using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
   [System.Serializable]
    public class BGData
    {
        public Transform trans;
        public float speed;
    }
    public List<BGData> bGDatas = new List<BGData>();

    /*
    
    // Start is called before the first frame update
    void Start()
    {
        
    }
    */
    // Update is called once per frame


    //trans[0].Translate(Vector3.down * Time.deltaTime * 5f);
    //trans[1].Translate(Vector3.down * Time.deltaTime * 3f);
    //trans[2].Translate(Vector3.down * Time.deltaTime * 1f);

    void Update()
    {


        for (int i = 0; i < bGDatas.Count; i++)
        {

            //��� ȭ�� �̵�
            bGDatas[i].trans.Translate(bGDatas[i].speed * Time.deltaTime * Vector3.down);
            //��� ȭ���� ȭ�� ������ �̵� ��
            if (bGDatas[i].trans.localPosition.y <= -12f) 
            {
                //��� ȭ���� ���� �̵���ǥ�� �̵�
                Vector3 vec = bGDatas[i].trans.localPosition;
                vec.y = 12;
                bGDatas[i].trans.localPosition = vec;
            }
        }
    }


}
